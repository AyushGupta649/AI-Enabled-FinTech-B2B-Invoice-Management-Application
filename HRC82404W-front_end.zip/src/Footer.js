import "./Footer.css";

export default function Footer() {
  return (
    <div className="footer">
      <p>Copyright 2022 Highradius. All Rights Reserved.</p>
    </div>
  );
}
